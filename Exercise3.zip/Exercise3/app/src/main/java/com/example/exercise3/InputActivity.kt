package com.example.exercise3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import com.google.android.material.textfield.TextInputEditText

class InputActivity : AppCompatActivity() {

    private lateinit var etFirstName : TextInputEditText
    private lateinit var etLastName : TextInputEditText
    private lateinit var rgGender : RadioGroup
    private lateinit var etHeight : TextInputEditText
    private lateinit var etWeight : TextInputEditText
    private lateinit var etContactNum : TextInputEditText

    private lateinit var btnClear : Button
    private lateinit var btnSubmit : Button

    private lateinit var gender : String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input)

        etFirstName = findViewById(R.id.etFirstName)
        etLastName = findViewById(R.id.etLastName)
        rgGender = findViewById(R.id.rgGender)
        etHeight = findViewById(R.id.etHeight)
        etWeight = findViewById(R.id.etWeight)
        etContactNum = findViewById(R.id.etContactNum)

        btnClear = findViewById(R.id.btnClear)
        btnSubmit = findViewById(R.id.btnSubmit)

        rgGender.setOnCheckedChangeListener { _, checkedId ->
            val selectedButton = findViewById<RadioButton>(checkedId)
            gender = selectedButton.text.toString()
        }

        btnClear.setOnClickListener{
            clear()
        }

        btnSubmit.setOnClickListener{
            if(!isBlank()) {
                val bmi = calculateBMI(
                    etWeight.text.toString().toDouble(),
                    etHeight.text.toString().toDouble()
                )

                val verdict = getVerdict(bmi, etHeight.text.toString().toDouble())

                val intent = Intent(this, VerdictActivity::class.java)
                intent.putExtra("verdict", verdict)
                intent.putExtra("name", etFirstName.text.toString())
                intent.putExtra("height", etHeight.text.toString())
                intent.putExtra("weight", etWeight.text.toString())
                intent.putExtra("gender", gender)
                if (verdict) {
                    intent.putExtra("last", String.format("%.2f", bmi))
                } else {
                    intent.putExtra("last", etContactNum.text.toString())
                }
                startActivity(intent)
                finish()
            }
        }


    }

    private fun clear() {
        etFirstName?.text = null
        etFirstName?.clearFocus()

        etLastName?.text = null
        etLastName?.clearFocus()

        etHeight?.text = null
        etHeight?.clearFocus()

        etWeight?.text = null
        etWeight?.clearFocus()

        etContactNum?.text = null
        etContactNum?.clearFocus()

        rgGender.check(R.id.dummyRadioButton)
    }

    private fun isBlank():  Boolean{
        if (etFirstName.text.isNullOrBlank() ||
            etLastName.text.isNullOrBlank() ||
            etHeight.text.isNullOrBlank() ||
            etWeight.text.isNullOrBlank() ||
            etContactNum.text.isNullOrBlank() ||
            rgGender.checkedRadioButtonId == -1
        ) {
            Toast.makeText(this, "Please enter all fields.", Toast.LENGTH_SHORT).show()
            return true
        }
        return false
    }


    private fun calculateBMI(weightKg: Double, heightCm: Double): Double {
        val heightM = heightCm / 100.0
        return weightKg / (heightM * heightM)
    }

    private fun getVerdict(bmi:Double, heightCm: Double): Boolean {
        return when (gender.lowercase()) {
            "male" -> {
                bmi in 20.0..24.0 && heightCm >= 170
            }
            "female" -> {
                bmi in 19.0..23.0 && heightCm >= 160
            }
            else -> false
        }
    }
}