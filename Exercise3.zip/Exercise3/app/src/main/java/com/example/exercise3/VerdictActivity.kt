package com.example.exercise3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class VerdictActivity : AppCompatActivity() {

    private lateinit var tvName : TextView
    private lateinit var ivImage : ImageView
    private lateinit var tvVerdict : TextView
    private lateinit var tvHeight : TextView
    private lateinit var tvWeight : TextView
    private lateinit var tvGender : TextView
    private lateinit var tvLast : TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verdict)

        val intent = intent
        val verdict = intent.getBooleanExtra("verdict", false)

        val name = intent.getStringExtra("name")
        val height = intent.getStringExtra("height")
        val weight = intent.getStringExtra("weight")
        val gender = intent.getStringExtra("gender")
        val last = intent.getStringExtra("last")

        tvName = findViewById(R.id.tvName)
        ivImage = findViewById(R.id.ivImage)
        tvVerdict = findViewById(R.id.tvVerdict)
        tvHeight = findViewById(R.id.tvHeight)
        tvWeight = findViewById(R.id.tvWeight)
        tvGender = findViewById(R.id.tvGender)
        tvLast = findViewById(R.id.tvLast)

        tvName.text = "Thank you for applying, $name!"
        tvHeight.text = "Your height: $height cm"
        tvWeight.text = "Your weight: $weight kg"
        tvGender.text = "Your gender: $gender"
        if(verdict){
            tvLast.text = "Calculated BMI: $last"
        }else {
            tvLast.text = "Your contact no.: $last"
        }

        if(verdict){
            tvVerdict.text = "You Qualify!"
            ivImage.setImageResource(R.drawable.p1_approved)
        } else {
            tvVerdict.text = "I will get in touch with your contact no."
            tvVerdict.textSize = 20f
            ivImage.setImageResource(R.drawable.p1_wait)
        }

    }

}